package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.exception.EntityNotFoundException;
import com.pf.fisioterapia.model.Paciente;
import com.pf.fisioterapia.repository.PacienteRepository;
import com.pf.fisioterapia.service.PacienteService;


@Service
public class PacienteServiceImpl implements PacienteService  {
	
	PacienteRepository pacienteRepository;
	
	public PacienteServiceImpl(PacienteRepository pacienteRepository) {
		this.pacienteRepository = pacienteRepository;
	}
	
	@Override
	public String createPaciente(Paciente paciente) {
		pacienteRepository.save(paciente);
		return "Success";
	}

	@Override
	public String updatePaciente(Paciente paciente) {
		pacienteRepository.save(paciente);
		return "Success";
	}

	@Override
	public String deletePaciente(Long pacienteId) {
		pacienteRepository.deleteById(pacienteId);
		return "Success";
	}

	@Override
	public Paciente getPaciente(Long pacienteId) {
		if(pacienteRepository.findById(pacienteId).isEmpty())
			throw new EntityNotFoundException("Paciente solicitado no existe");
		return pacienteRepository.findById(pacienteId).get();
	}

	@Override
	public List<Paciente> getPacientes() {
		return pacienteRepository.findAll();
	}
}
