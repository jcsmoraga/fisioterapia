package com.pf.fisioterapia.service.impl;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.model.UsuarioRol;
import com.pf.fisioterapia.repository.UsuarioRolRepository;
import com.pf.fisioterapia.service.UsuarioRolService;

@Service
public class UsuarioRolServiceImpl implements UsuarioRolService {

	private final  UsuarioRolRepository usuarioRolRepository;

	public UsuarioRolServiceImpl(UsuarioRolRepository usuarioRolRepository) {
	        this.usuarioRolRepository = usuarioRolRepository;
	}

	@Override
	public UsuarioRol saveUsuarioRol(UsuarioRol usuarioRol) {
		return usuarioRolRepository.save(usuarioRol);
	}

	@Override
	public void deleteUsuarioRol(UsuarioRol usuarioRol) {
		usuarioRolRepository.deleteById(null);
	}
}
