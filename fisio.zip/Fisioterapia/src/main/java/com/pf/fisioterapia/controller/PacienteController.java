package com.pf.fisioterapia.controller;

import java.util.List;
import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pf.fisioterapia.model.Paciente;
import com.pf.fisioterapia.response.ResponseHandler;
import com.pf.fisioterapia.service.PacienteService;

@RestController
@RequestMapping("/paciente")
public class PacienteController {

	private final PacienteService pacienteService;
	private final MessageSource messageSource;

	public PacienteController(PacienteService pacienteService, MessageSource messageSource) {
		this.pacienteService = pacienteService;
		this.messageSource = messageSource;
	}

	@GetMapping("{pacienteId}")
	public ResponseEntity<Object> getPaciente(@PathVariable("pacienteId") Long pacienteId, Locale locale) {
		String successMessage = messageSource.getMessage("paciente.get.success", null, locale);
		return ResponseHandler.responseBuilder(successMessage, HttpStatus.OK, pacienteService.getPaciente(pacienteId));
	}

	@GetMapping()
	public List<Paciente> getPacientes() {
		return pacienteService.getPacientes();
	}

	@PostMapping
	public ResponseEntity<String> createPaciente(@RequestBody Paciente paciente, Locale locale) {
		pacienteService.createPaciente(paciente);
		String successMessage = messageSource.getMessage("paciente.creation.success", null, locale);
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}

	@PutMapping
	public ResponseEntity<String> updatePaciente(@RequestBody Paciente paciente, Locale locale) {
		pacienteService.updatePaciente(paciente);
		String successMessage = messageSource.getMessage("paciente.update.success", null, locale);
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	@DeleteMapping({ "{pacienteId}" })
	public ResponseEntity<String> deletePaciente(@PathVariable("pacienteId") Long pacienteId, Locale locale) {
		pacienteService.deletePaciente(pacienteId);
		String successMessage = messageSource.getMessage("paciente.deletion.success", null, locale);
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}
}
