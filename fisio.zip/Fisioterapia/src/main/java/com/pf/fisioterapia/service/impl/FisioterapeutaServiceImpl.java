package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.model.Fisioterapeuta;
import com.pf.fisioterapia.repository.FisioterapeutaRepository;
import com.pf.fisioterapia.service.FisioterapeutaService;

@Service
public class FisioterapeutaServiceImpl implements FisioterapeutaService {

	private FisioterapeutaRepository fisioterapeutaRepository;

	public FisioterapeutaServiceImpl(FisioterapeutaRepository fisioterapeutaRepository) {
		super();
		this.fisioterapeutaRepository = fisioterapeutaRepository;
	}

	@Override
	public Fisioterapeuta getFisioterapeuta(Long id) {
		return fisioterapeutaRepository.findById(id).orElse(null);
	}

	@Override
	public List<Fisioterapeuta> getAllFisioterapeutas() {
		return fisioterapeutaRepository.findAll();
	}

	@Override
	public Fisioterapeuta saveFisioterapeuta(Fisioterapeuta fisioterapeuta) {
		return fisioterapeutaRepository.save(fisioterapeuta);
	}

	@Override
	public String deleteFisioterapeuta(Long id) {
		fisioterapeutaRepository.deleteById(id);
		return "Success";
	}
}
