package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.model.ObjetivoTratamiento;
import com.pf.fisioterapia.repository.ObjetivoTratamientoRepository;
import com.pf.fisioterapia.service.ObjetivoTratamientoService;

@Service
public class ObjetivoTratamientoServiceImpl implements ObjetivoTratamientoService {

    private final ObjetivoTratamientoRepository objetivoTratamientoRepository;

    public ObjetivoTratamientoServiceImpl(ObjetivoTratamientoRepository objetivoTratamientoRepository) {
        this.objetivoTratamientoRepository = objetivoTratamientoRepository;
    }

    @Override
    public ObjetivoTratamiento save(ObjetivoTratamiento objetivoTratamiento) {
        return objetivoTratamientoRepository.save(objetivoTratamiento);
    }

    @Override
    public ObjetivoTratamiento getById(Long id) {
        return objetivoTratamientoRepository.findById(id).orElse(null);
    }

    @Override
    public List<ObjetivoTratamiento> getAll() {
        return objetivoTratamientoRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        objetivoTratamientoRepository.deleteById(id);
    }
}
