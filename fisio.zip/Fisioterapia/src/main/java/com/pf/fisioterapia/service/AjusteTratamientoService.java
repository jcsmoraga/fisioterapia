package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.AjusteTratamiento;

public interface AjusteTratamientoService {
    AjusteTratamiento save(AjusteTratamiento ajusteTratamiento);
    AjusteTratamiento getById(Long id);
    List<AjusteTratamiento> getAll();
    void deleteById(Long id);
}
