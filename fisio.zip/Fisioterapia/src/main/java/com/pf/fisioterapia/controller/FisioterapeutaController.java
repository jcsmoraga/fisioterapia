package com.pf.fisioterapia.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.pf.fisioterapia.model.Fisioterapeuta;
import com.pf.fisioterapia.service.FisioterapeutaService;

@RestController
@RequestMapping("/fisioterapeutas")
public class FisioterapeutaController {
    
    private final FisioterapeutaService fisioterapeutaService;

    public FisioterapeutaController(FisioterapeutaService fisioterapeutaService) {
    	super();
        this.fisioterapeutaService = fisioterapeutaService;
    }

    @GetMapping("/{id}")
    public Fisioterapeuta getFisioterapeuta(@PathVariable Long id) {
        return fisioterapeutaService.getFisioterapeuta(id);
    }

    @GetMapping
    public List<Fisioterapeuta> getAllFisioterapeutas() {
        return fisioterapeutaService.getAllFisioterapeutas();
    }

    @PostMapping
    public Fisioterapeuta createFisioterapeuta(@RequestBody Fisioterapeuta fisioterapeuta) {
        return fisioterapeutaService.saveFisioterapeuta(fisioterapeuta);
    }

    @PutMapping("/{id}")
    public Fisioterapeuta updateFisioterapeuta(@PathVariable Long id, @RequestBody Fisioterapeuta fisioterapeuta) {
        return fisioterapeutaService.saveFisioterapeuta(fisioterapeuta);
    }

    @DeleteMapping("/{id}")
    public void deleteFisioterapeuta(@PathVariable Long id) {
        fisioterapeutaService.deleteFisioterapeuta(id);
    }
}
