package com.pf.fisioterapia.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "sesiones")
@Data
public class Sesion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_sesion") 
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_tratamiento", nullable = false)
    private Tratamiento tratamiento;

    @ManyToOne
    @JoinColumn(name = "id_fisioterapeuta", nullable = false)
    private Fisioterapeuta fisioterapeuta;

    @Column(name = "fecha_sesion", updatable = false)
    private LocalDateTime fechaSesion;

    private String tecnicaAplicada;
    private Integer tiempoAplicacion; 
    private String respuestaPaciente;
}
