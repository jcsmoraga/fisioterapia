package com.pf.fisioterapia.service;

import com.pf.fisioterapia.model.UsuarioRol;

public interface UsuarioRolService {

	 UsuarioRol saveUsuarioRol(UsuarioRol usuarioRol);
	 void deleteUsuarioRol(UsuarioRol usuarioRol);
}
