package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.model.Evaluacion;
import com.pf.fisioterapia.repository.EvaluacionRepository;
import com.pf.fisioterapia.service.EvaluacionService;

@Service
public class EvaluacionServiceImpl implements EvaluacionService {

    private final EvaluacionRepository evaluacionRepository;

    public EvaluacionServiceImpl(EvaluacionRepository evaluacionRepository) {
        this.evaluacionRepository = evaluacionRepository;
    }

    @Override
    public Evaluacion save(Evaluacion evaluacion) {
        return evaluacionRepository.save(evaluacion);
    }

    @Override
    public Evaluacion getById(Long id) {
        return evaluacionRepository.findById(id).orElse(null);
    }

    @Override
    public List<Evaluacion> getAll() {
        return evaluacionRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        evaluacionRepository.deleteById(id);
    }
}
