package com.pf.fisioterapia.security;

import com.pf.fisioterapia.model.Usuario;
import com.pf.fisioterapia.repository.UsuarioRepository;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class DetallesUsuarioService {
//implements UserDetailsService {

	/*private UsuarioRepository usuarioRepository;

	public DetallesUsuarioService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Usuario usuario = usuarioRepository.findByEmail(email)
				.orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + email));

		List<GrantedAuthority> authorities = usuario.getRoles().stream()
				.map(usuarioRol -> new SimpleGrantedAuthority(usuarioRol.getRol().getNombre()))
				.collect(Collectors.toList());

		return new User(
				usuario.getEmail(), 
				usuario.getPassword(),
				usuario.isEnabled(), 
				true, 
				true, 
				true, 
				authorities);
	}*/
	 /*@Bean
	    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	        http
	        .csrf().disable()  // Disable CSRF protection for now
	            .authorizeHttpRequests(authorize -> authorize
	                .requestMatchers("/public/**").permitAll() 
	                .anyRequest().authenticated()            
	            )
	            .httpBasic(); 
	        return http.build();
	    }

	    @Bean
	    public UserDetailsService userDetailsService() {
	        UserDetails user = User.builder()
	            .username("admin")
	            .password("{noop}F1510Ter@p145!") 
	            .roles("USER")
	            .build();
	        return new InMemoryUserDetailsManager(user);
	    }

		@Override
		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			// TODO Auto-generated method stub
			return null;
		}*/
}
