package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.Patologia;

public interface PatologiaService {
    Patologia save(Patologia patologia);
    Patologia getById(Long id);
    List<Patologia> getAll();
    void deleteById(Long id);
}
