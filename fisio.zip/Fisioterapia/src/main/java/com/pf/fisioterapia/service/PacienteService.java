package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.Paciente;

public interface PacienteService {
	 String createPaciente(Paciente paciente);
     String updatePaciente(Paciente paciente);
	 String deletePaciente(Long pacienteId);
	 Paciente getPaciente(Long pacienteId);
	 List<Paciente> getPacientes();
}
