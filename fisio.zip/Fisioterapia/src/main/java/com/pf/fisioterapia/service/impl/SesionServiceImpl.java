package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.model.Sesion;
import com.pf.fisioterapia.repository.SesionRepository;
import com.pf.fisioterapia.service.SesionService;

@Service
public class SesionServiceImpl implements SesionService {

    private final SesionRepository sesionRepository;

    public SesionServiceImpl(SesionRepository sesionRepository) {
        this.sesionRepository = sesionRepository;
    }

    @Override
    public Sesion save(Sesion sesion) {
        return sesionRepository.save(sesion);
    }

    @Override
    public Sesion getById(Long id) {
        return sesionRepository.findById(id).orElse(null);
    }

    @Override
    public List<Sesion> getAll() {
        return sesionRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        sesionRepository.deleteById(id);
    }
}
