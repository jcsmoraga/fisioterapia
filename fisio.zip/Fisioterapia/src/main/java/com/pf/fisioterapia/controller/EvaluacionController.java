package com.pf.fisioterapia.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.pf.fisioterapia.model.Evaluacion;
import com.pf.fisioterapia.service.EvaluacionService;

@RestController
@RequestMapping("/evaluaciones")
public class EvaluacionController {

    private final EvaluacionService evaluacionService;

    public EvaluacionController(EvaluacionService evaluacionService) {
        this.evaluacionService = evaluacionService;
    }

    @GetMapping("/{id}")
    public Evaluacion getEvaluacion(@PathVariable Long id) {
        return evaluacionService.getById(id);
    }

    @GetMapping
    public List<Evaluacion> getAllEvaluaciones() {
        return evaluacionService.getAll();
    }

    @PostMapping
    public Evaluacion createEvaluacion(@RequestBody Evaluacion evaluacion) {
        return evaluacionService.save(evaluacion);
    }

    @PutMapping("/{id}")
    public Evaluacion updateEvaluacion(@PathVariable Long id, @RequestBody Evaluacion evaluacion) {
        return evaluacionService.save(evaluacion);
    }

    @DeleteMapping("/{id}")
    public void deleteEvaluacion(@PathVariable Long id) {
        evaluacionService.deleteById(id);
    }
}

