package com.pf.fisioterapia.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pf.fisioterapia.model.AjusteTratamiento;
import com.pf.fisioterapia.service.AjusteTratamientoService;

@RestController
@RequestMapping("/ajustes-tratamiento")
public class AjusteTratamientoController {

    private final AjusteTratamientoService ajusteTratamientoService;

    public AjusteTratamientoController(AjusteTratamientoService ajusteTratamientoService) {
        this.ajusteTratamientoService = ajusteTratamientoService;
    }

    @GetMapping("/{id}")
    public AjusteTratamiento getById(@PathVariable Long id) {
        return ajusteTratamientoService.getById(id);
    }

    @PostMapping
    public AjusteTratamiento create(@RequestBody AjusteTratamiento ajusteTratamiento) {
        return ajusteTratamientoService.save(ajusteTratamiento);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        ajusteTratamientoService.deleteById(id);
        return "Deleted successfully";
    }
}
