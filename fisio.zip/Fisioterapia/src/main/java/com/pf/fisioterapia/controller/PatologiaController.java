package com.pf.fisioterapia.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.pf.fisioterapia.model.Patologia;
import com.pf.fisioterapia.service.PatologiaService;

@RestController
@RequestMapping("/patologias")
public class PatologiaController {

    private final PatologiaService patologiaService;

    public PatologiaController(PatologiaService patologiaService) {
        this.patologiaService = patologiaService;
    }

    @GetMapping("/{id}")
    public Patologia getPatologia(@PathVariable Long id) {
        return patologiaService.getById(id);
    }

    @GetMapping
    public List<Patologia> getAllPatologias() {
        return patologiaService.getAll();
    }

    @PostMapping
    public Patologia createPatologia(@RequestBody Patologia patologia) {
        return patologiaService.save(patologia);
    }

    @PutMapping("/{id}")
    public Patologia updatePatologia(@PathVariable Long id, @RequestBody Patologia patologia) {
        return patologiaService.save(patologia);
    }

    @DeleteMapping("/{id}")
    public void deletePatologia(@PathVariable Long id) {
        patologiaService.deleteById(id);
    }
}
