package com.pf.fisioterapia.service;



import java.util.List;

import com.pf.fisioterapia.model.Permiso;

public interface PermisoService {
    Permiso save(Permiso permiso);
    Permiso getById(Long id);
    List<Permiso> getAll();
    void deleteById(Long id);
}