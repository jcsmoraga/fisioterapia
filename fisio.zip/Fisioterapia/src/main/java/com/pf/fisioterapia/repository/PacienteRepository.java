package com.pf.fisioterapia.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pf.fisioterapia.model.Paciente;

public interface PacienteRepository extends JpaRepository<Paciente, Long>  {
	

}
