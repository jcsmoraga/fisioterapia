package com.pf.fisioterapia.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class RolPermisoId implements Serializable {
    private Long rol;
    private Long permiso;
}
