package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.ObjetivoTratamiento;

public interface ObjetivoTratamientoService {
    ObjetivoTratamiento save(ObjetivoTratamiento objetivoTratamiento);
    ObjetivoTratamiento getById(Long id);
    List<ObjetivoTratamiento> getAll();
    void deleteById(Long id);
}
