package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.Rol;

public interface RolService {
    Rol save(Rol rol);
    Rol getById(Long id);
    List<Rol> getAll();
    void deleteById(Long id);
}
